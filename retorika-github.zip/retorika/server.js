#!/usr/bin/env node
"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = Number(process.env.PORT || 3000);
const HOST = "0.0.0.0";
const ROOT = __dirname;
const WEB_DIR = path.join(ROOT, "web");
const DOWNLOADS = {
  "/downloads/retorika.apk": {
    file: path.join(ROOT, "releases", "retorika.apk"),
    contentType: "application/vnd.android.package-archive",
    filename: "retorika.apk"
  },
  "/downloads/retorika-github.zip": {
    file: "/home/user/retorika-github.zip",
    contentType: "application/zip",
    filename: "retorika-github.zip"
  }
};

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".apk": "application/vnd.android.package-archive",
  ".zip": "application/zip"
};

const server = http.createServer((req, res) => {
  const urlPath = (req.url || "/").split("?")[0];

  if (Object.prototype.hasOwnProperty.call(DOWNLOADS, urlPath)) {
    const dl = DOWNLOADS[urlPath];
    if (!fs.existsSync(dl.file)) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Файл не найден.");
      return;
    }
    const stat = fs.statSync(dl.file);
    res.writeHead(200, {
      "Content-Type": dl.contentType,
      "Content-Length": stat.size,
      "Content-Disposition": `attachment; filename="${dl.filename}"`,
      "Cache-Control": "no-cache"
    });
    fs.createReadStream(dl.file).pipe(res);
    return;
  }

  let relPath = urlPath === "/" ? "/index.html" : urlPath;
  const safePath = path.normalize(relPath).replace(/^(\.\.[/\\])+/, "");
  let fullPath = path.join(WEB_DIR, safePath);

  if (!fullPath.startsWith(WEB_DIR)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  if (!fs.existsSync(fullPath) || fs.statSync(fullPath).isDirectory()) {
    fullPath = path.join(WEB_DIR, "index.html");
  }

  const ext = path.extname(fullPath).toLowerCase();
  res.writeHead(200, {
    "Content-Type": MIME[ext] || "application/octet-stream",
    "Cache-Control": ext === ".html" ? "no-cache" : "public, max-age=3600"
  });
  fs.createReadStream(fullPath).pipe(res);
});

server.listen(PORT, HOST, () => {
  console.log(`Retorika (Mate XT) server listening on http://${HOST}:${PORT}`);
});
