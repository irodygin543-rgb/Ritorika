-keep class ru.krasnorechie.matext.MainActivity$MateXTBridge { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
